from __future__ import unicode_literals

from django.apps import AppConfig


class DestinationsAppConfig(AppConfig):
    name = 'destinations_app'
